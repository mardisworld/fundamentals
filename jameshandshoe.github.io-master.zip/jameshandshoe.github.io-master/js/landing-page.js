$(document).ready(function(){
	$('#s3').cycle({ 
    	fx:    'fade', 
    	speed:  1500 
 	});

 	$('#monthlyBudget').click(function(){
 		window.open("http://codepen.io/jhandshoe/pen/rLmgrr");
 	});

 	$('#ajaxTutorial').click(function(){
 		window.open("http://ajax-tutorial.herokuapp.com/");
 	});

 	$('#meditationApp').click(function(){
 		window.open("https://meditate-app.herokuapp.com/");
 	});

 	$('#meanStack').click(function(){
 		window.open("http://mean-unmultipliable-armpit.mybluemix.net/");
 	});

 	$('#workoutlog').click(function(){
 		window.open("https://workoutweb-1150-jhandshoe.herokuapp.com/");
 	});

 	$('#windmill').click(function(){
 		window.open("https://youtu.be/MU9KDO6K38o");
 	});

 	$('#react').click(function(){
 		window.open("http://reactyoutubesearch.herokuapp.com/");
 	});
 	
});
